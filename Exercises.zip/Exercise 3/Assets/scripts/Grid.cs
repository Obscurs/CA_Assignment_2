﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PathFinding;
public class Grid : FiniteGraph<GridCell,CellConnection,GridConnections>
{
    public Grid(int numCellsX, int numCellsZ, int sizeCell, int startPosX, int startPosY, int[,] obstaclesPositions) : base()
    {
        //CREATE NODES
        int currentNodeIndex = 0;
        for (int i = 0; i < numCellsX; ++i)
        {
            for (int j = 0; j < numCellsZ; ++j)
            {
                if (obstaclesPositions[i, j] == -1)
                {
                    nodes.Add(new GridCell(currentNodeIndex,i * numCellsZ + j, new Vector2(i* sizeCell+ startPosX, j* sizeCell + startPosY)));
                    currentNodeIndex += 1;
                    connections.Add(new GridConnections());
                    //Debug.Log("Cell created: " + i + " " + j + " " + i * numCellsZ + j);
                }
            }
        }
        //CREATE CONNECTIONS
        currentNodeIndex = 0;
        for (int i = 0; i < numCellsX; ++i)
        {
            for (int j = 0; j < numCellsZ; ++j)
            {
                if (obstaclesPositions[i, j] == -1)
                {
                    for (int aux_i = i - 1; aux_i <= i + 1; ++aux_i)
                    {
                        for (int aux_j = j - 1; aux_j <= j + 1; ++aux_j)
                        {
                            if (aux_i >= 0 && aux_j >= 0 && aux_i < numCellsX && aux_j < numCellsZ && (aux_i != i || aux_j != j) && obstaclesPositions[aux_i, aux_j] == -1)
                            {
                                GridCell auxCell = getNodeByIdAux(aux_i * numCellsZ + aux_j);
                                if(auxCell == null)
                                {
                                    Debug.LogError("Cell not found: " + aux_i + " " + aux_j +" "+ aux_i * numCellsZ + aux_j);
                                }
                                bool valid = true;
                                //check corners are accessible
                                if((aux_i == i - 1 && aux_j == j - 1) || (aux_i == i + 1 && aux_j == j + 1) || (aux_i == i + 1 && aux_j == j - 1) || (aux_i == i - 1 && aux_j == j + 1))
                                {
                                    if (obstaclesPositions[i, aux_j] != -1 && obstaclesPositions[aux_i, j] != -1)
                                        valid = false;
                                }
                                if(valid)
                                    connections[currentNodeIndex].Add(new CellConnection(nodes[currentNodeIndex], auxCell));
                                //Debug.Log("connection created for node: " + i * numCellsZ + j);
                            }
                        }
                    }

                    currentNodeIndex++;
                }
            }
        }
    }
    public GridCell getNodeByIdAux(int id)
    {
        foreach(GridCell gc in nodes)
        {
            if (gc.id_aux == id)
                return gc;
        }
        return null;
    }

}
