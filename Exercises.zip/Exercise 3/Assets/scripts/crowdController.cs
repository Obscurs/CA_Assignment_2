﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class crowdController : MonoBehaviour
{
    public GameObject agent;
    public GameObject walls;
    public const int N_NORMAL_AGENTS = 5;
    
    public List<GameObject> agentListNormal = new List<GameObject>();
   
    void Awake()
    {
        walls = GameObject.Find("Walls");

    }
    // Start is called before the first frame update
    void Start()
    {
        if (!walls.GetComponent<gridController>().inited)
            Debug.LogError("Error: Grid is not inited");
        List<Vector2> positions = new List<Vector2>();
        int countInstantiated = 0;
        while(countInstantiated < N_NORMAL_AGENTS)
        {
            Vector2 newPos = walls.GetComponent<gridController>().GetRandomAvailableCell();
            if(!positions.Contains(newPos))
            {
                positions.Add(newPos);
                GameObject currAgent;
                currAgent = Instantiate(agent, new Vector3(newPos.x, 0, newPos.y), Quaternion.identity);
                agentListNormal.Add(currAgent);
                countInstantiated += 1;
            }
        }
        countInstantiated = 0;
        
        /*
        for(int i=0; i< 10; ++i)
        {
            for (int j = 0; j < 10; ++j)
            {
                Instantiate(agent, new Vector3(i * 2, 0, j * 2), Quaternion.identity);

            }
        }*/
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void changePathfinder()
    {
        foreach(GameObject agent in agentListNormal)
        {
            agent.GetComponent<character>().changePathFinder();
        }
    }
}
