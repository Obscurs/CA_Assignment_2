using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System;

namespace PathFinding{

	public class A_Star<TNode,TConnection,TNodeConnection,TGraph,THeuristic> : PathFinder<TNode,TConnection,TNodeConnection,TGraph,THeuristic>
	where TNode : Node
	where TConnection : Connection<TNode>
	where TNodeConnection : NodeConnections<TNode,TConnection>
	where TGraph : Graph<TNode,TConnection,TNodeConnection>
	where THeuristic : Heuristic<TNode>
	{
	// Class that implements the A* pathfinding algorithm
	// You have to implement the findpath function.
	// You can add whatever you need.
				
		//protected List<TNode> visitedNodes; // list of visited nodes 
		
		//protected NodeRecord currentBest; // current best node found
		
		public enum NodeRecordCategory{ OPEN, CLOSED, UNVISITED };
				
		public class NodeRecord: /*IComparer<NodeRecord>*/ IComparable<NodeRecord>
		{	
		// You can use (or not) this structure to keep track of the information that we need for each node
			
			public NodeRecord(){}
			
			public TNode node; 
			public NodeRecord connection;	// connection traversed to reach this node 
			public float costSoFar; // cost accumulated to reach this node
			public float estimatedTotalCost; // estimated total cost to reach the goal from this node
			public NodeRecordCategory category; // category of the node: open, closed or unvisited
			public int depth; // depth in the search graph

			public int CompareTo(NodeRecord other)
            {
				if (this.estimatedTotalCost > other.estimatedTotalCost)
				{
					return 1;
				}
				else if (this.estimatedTotalCost < other.estimatedTotalCost)
				{
					return -1;
				}
				else
				{
					return -1;
				}
			}
			/*public int Compare(NodeRecord x, NodeRecord y)
			{
				if (x.estimatedTotalCost < y.estimatedTotalCost)
				{
					return 1;
				}
				else if (x.estimatedTotalCost > y.estimatedTotalCost)
				{
					return -1;
				}
				else
				{
					return 0;
				}
			}*/
		};
		/*public class NodeRecordComparer : IComparer<NodeRecord>
		{
			
		}*/
		public	A_Star(int maxNodes, float maxTime, int depth):base(){ 
			
			//visitedNodes = new List<TNode> ();
			
		}

		//public virtual List<TNode> getVisitedNodes(){
		//	return visitedNodes;
		//}
		
		public override List<TNode> findpath(TGraph graph, TNode start, TNode end, THeuristic heuristic, ref int found)
		{
			List<TNode> path = new List<TNode>();
			Dictionary<TNode, int> mapNodeRecord = new Dictionary<TNode, int>();
			List<NodeRecord> nodeRecords = new List<NodeRecord>();
			SortedList<NodeRecord,int> openedNodes = new SortedList<NodeRecord, int>();
			NodeRecord startRecord = new NodeRecord();
			NodeRecord endRecord = null;
			startRecord.node = start;
			startRecord.connection = null;
			startRecord.depth = 0;
			startRecord.category = NodeRecordCategory.OPEN;
			startRecord.costSoFar = 0;
			startRecord.estimatedTotalCost = heuristic.estimateCost(start);

			int currentIndex = 0;
			openedNodes.Add(startRecord, startRecord.node.id);
			nodeRecords.Add(startRecord);
			mapNodeRecord.Add(start, currentIndex);
			currentIndex += 1;
			while(openedNodes.Count > 0)
            {
				NodeRecord current = openedNodes.Keys[0];
				openedNodes.RemoveAt(0);
				current.category = NodeRecordCategory.CLOSED;
				if(current.node == end)
                {
					endRecord = current;
					break;
				}
				TNodeConnection neighbors = graph.getConnections(current.node);

				foreach(TConnection neighbor in neighbors.connections)
                {
					float cost = current.costSoFar + neighbor.getCost();

					int currentRecordNeighborIndex = -1;
					bool neighborExists = mapNodeRecord.TryGetValue(neighbor.getToNode(), out currentRecordNeighborIndex);
					if (!neighborExists)
                    {
						NodeRecord newRecord = new NodeRecord();
						newRecord.node = neighbor.getToNode();
						newRecord.connection = null;
						newRecord.depth = -1;
						newRecord.category = NodeRecordCategory.UNVISITED;
						newRecord.costSoFar = -1;
						newRecord.estimatedTotalCost = -1;
						nodeRecords.Add(newRecord);
						mapNodeRecord.Add(neighbor.getToNode(), currentIndex);
						currentRecordNeighborIndex = currentIndex;
						currentIndex += 1;
						
					}
					NodeRecord neighborRecord = nodeRecords[currentRecordNeighborIndex];
					if (neighborRecord.category == NodeRecordCategory.OPEN && cost < neighborRecord.costSoFar)
						neighborRecord.category = NodeRecordCategory.UNVISITED;
					if (neighborRecord.category == NodeRecordCategory.CLOSED && cost < neighborRecord.costSoFar)
						neighborRecord.category = NodeRecordCategory.UNVISITED;
					if(neighborRecord.category != NodeRecordCategory.CLOSED && neighborRecord.category != NodeRecordCategory.OPEN)
                    {
						
						neighborRecord.costSoFar = cost;
						neighborRecord.category = NodeRecordCategory.OPEN;
						neighborRecord.estimatedTotalCost = neighborRecord.costSoFar+ heuristic.estimateCost(neighborRecord.node);
						neighborRecord.connection = current;
						if (!openedNodes.ContainsValue(neighborRecord.node.id))
						{
							/*if(openedNodes.ContainsKey(neighborRecord))
                            {
								int index = openedNodes.IndexOfKey(neighborRecord);
								Debug.LogError("I dont understand");
                            }*/
							openedNodes.Add(neighborRecord, neighborRecord.node.id);

						}

						
					}
				}
			}
			if(endRecord !=null)
			{
				NodeRecord currentPathRecord = endRecord;
				while (currentPathRecord.connection != null)
                {
					path.Add(currentPathRecord.node);
					currentPathRecord = currentPathRecord.connection;
				}
				//path.Add(currentPathRecord.node);
				Debug.Log("Path found");
				found = 1;
			}
            else
            {
				Debug.Log("Path not found");
				found = 0;
			}

			path.Reverse();
			return path;
		}

   
    };

}