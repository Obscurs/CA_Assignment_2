using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System;

namespace PathFinding{

	public class A_Star_Bidirectional<TNode,TConnection,TNodeConnection,TGraph,THeuristic> : PathFinder<TNode,TConnection,TNodeConnection,TGraph,THeuristic>
	where TNode : Node
	where TConnection : Connection<TNode>
	where TNodeConnection : NodeConnections<TNode,TConnection>
	where TGraph : Graph<TNode,TConnection,TNodeConnection>
	where THeuristic : Heuristic<TNode>
	{
	// Class that implements the A* pathfinding algorithm
	// You have to implement the findpath function.
	// You can add whatever you need.
				
		//protected List<TNode> visitedNodes; // list of visited nodes 
		
		//protected NodeRecord currentBest; // current best node found
		
		public enum NodeRecordCategory{ OPEN, CLOSED, UNVISITED };
				
		public class NodeRecord: /*IComparer<NodeRecord>*/ IComparable<NodeRecord>
		{	
		// You can use (or not) this structure to keep track of the information that we need for each node
			
			public NodeRecord(){}
			
			public TNode node; 
			public NodeRecord connection0;   // connection traversed to reach this node 
			public NodeRecord connection1;   // connection traversed to reach this node 
			public float costSoFar0; // cost accumulated to reach this node
			public float costSoFar1; // cost accumulated to reach this node
			public float estimatedTotalCost; // estimated total cost to reach the goal from this node
			public NodeRecordCategory category; // category of the node: open, closed or unvisited
			public int depth; // depth in the search graph
			public int direction;
			public int CompareTo(NodeRecord other)
            {
				if (this.estimatedTotalCost > other.estimatedTotalCost)
				{
					return 1;
				}
				else if (this.estimatedTotalCost < other.estimatedTotalCost)
				{
					return -1;
				}
				else
				{
					return -1;
				}
			}
			/*public int Compare(NodeRecord x, NodeRecord y)
			{
				if (x.estimatedTotalCost < y.estimatedTotalCost)
				{
					return 1;
				}
				else if (x.estimatedTotalCost > y.estimatedTotalCost)
				{
					return -1;
				}
				else
				{
					return 0;
				}
			}*/
		};
		/*public class NodeRecordComparer : IComparer<NodeRecord>
		{
			
		}*/
		public A_Star_Bidirectional(int maxNodes, float maxTime, int depth):base(){ 
			
			//visitedNodes = new List<TNode> ();
			
		}

		//public virtual List<TNode> getVisitedNodes(){
		//	return visitedNodes;
		//}
		
		public override List<TNode> findpath(TGraph graph, TNode start, TNode end, THeuristic heuristic, ref int found)
		{

			List<TNode> path = new List<TNode>();
			if (start == end)
			{
				path.Add(end);
				return path;
			}
			Dictionary<TNode, int> mapNodeRecord = new Dictionary<TNode, int>();
			List<NodeRecord> nodeRecords = new List<NodeRecord>();
			SortedList<NodeRecord,int> openedNodesStart = new SortedList<NodeRecord, int>();
			SortedList<NodeRecord, int> openedNodesEnd = new SortedList<NodeRecord, int>();
			NodeRecord startRecord = new NodeRecord();
			NodeRecord endRecord = new NodeRecord();

			NodeRecord startRecordEnd = null;
			NodeRecord endRecordEnd = null;

			startRecord.node = start;
			startRecord.connection0 = null;
			startRecord.connection1 = null;
			startRecord.depth = 0;
			startRecord.category = NodeRecordCategory.OPEN;
			startRecord.costSoFar0 = 0;
			startRecord.costSoFar1 = 0;
			startRecord.estimatedTotalCost = heuristic.estimateCostTwoNodes(start, end);
			startRecord.direction = 0;

			endRecord.node = end;
			endRecord.connection0 = null;
			endRecord.connection1 = null;
			endRecord.depth = 0;
			endRecord.category = NodeRecordCategory.OPEN;
			endRecord.costSoFar0 = 0;
			endRecord.costSoFar1 = 0;
			endRecord.estimatedTotalCost = heuristic.estimateCostTwoNodes(start, end);
			endRecord.direction = 1;

			int currentIndex = 0;
			openedNodesStart.Add(startRecord, startRecord.node.id);
			openedNodesEnd.Add(endRecord, endRecord.node.id);
			nodeRecords.Add(startRecord);
			nodeRecords.Add(endRecord);
			mapNodeRecord.Add(start, currentIndex);
			currentIndex += 1;
			mapNodeRecord.Add(end, currentIndex);
			currentIndex += 1;

			int currentDirection = 0;
			bool endReached0 = false;
			bool endReached1 = false;
			bool directionsHit = false;
			while(openedNodesStart.Count > 0 && openedNodesEnd.Count > 0)
            {
				NodeRecord current;
				if (currentDirection == 0)
				{
					current = openedNodesStart.Keys[0];
					openedNodesStart.RemoveAt(0);
					current.category = NodeRecordCategory.CLOSED;

					if (current.node == end)
					{
						endReached0 = true;
						startRecordEnd = current;
						break;
					}
					else if (current.direction != currentDirection)
					{
						startRecordEnd = current;
						endRecordEnd = current;
						directionsHit = true;
						break;
					}
				}
                else
                {
					current = openedNodesEnd.Keys[0];
					openedNodesEnd.RemoveAt(0);
					current.category = NodeRecordCategory.CLOSED;

					if (current.node == start)
					{
						endReached1 = true;
						startRecordEnd = current;
						break;
					}
					else if (current.direction != currentDirection)
					{
						startRecordEnd = current;
						endRecordEnd = current;
						directionsHit = true;
						break;
					}
				}
				
				TNodeConnection neighbors = graph.getConnections(current.node);

				foreach (TConnection neighbor in neighbors.connections)
				{
					float cost;
					if(currentDirection == 0)
						cost = current.costSoFar0 + neighbor.getCost();
					else
						cost = current.costSoFar1 + neighbor.getCost();
					int currentRecordNeighborIndex = -1;
					bool neighborExists = mapNodeRecord.TryGetValue(neighbor.getToNode(), out currentRecordNeighborIndex);
					if (!neighborExists)
					{
						NodeRecord newRecord = new NodeRecord();
						newRecord.node = neighbor.getToNode();
						newRecord.connection0 = null;
						newRecord.connection1 = null;
						newRecord.depth = -1;
						newRecord.category = NodeRecordCategory.UNVISITED;
						newRecord.costSoFar0 = -1;
						newRecord.costSoFar0 = -1;
						newRecord.estimatedTotalCost = -1;
						nodeRecords.Add(newRecord);
						mapNodeRecord.Add(neighbor.getToNode(), currentIndex);
						currentRecordNeighborIndex = currentIndex;
						currentIndex += 1;

					}
					NodeRecord neighborRecord = nodeRecords[currentRecordNeighborIndex];
					if (neighborRecord.category == NodeRecordCategory.OPEN || neighborRecord.category == NodeRecordCategory.CLOSED)
					{
						if (currentDirection == 0)
						{
							if (cost < neighborRecord.costSoFar0 || neighborRecord.costSoFar0 == -1)
								neighborRecord.category = NodeRecordCategory.UNVISITED;
						}
						else
						{
							if (cost < neighborRecord.costSoFar1 || neighborRecord.costSoFar1 == -1)
								neighborRecord.category = NodeRecordCategory.UNVISITED;
						}
					}
					/*else if (neighborRecord.category == NodeRecordCategory.OPEN && neighborRecord.direction != currentDirection)
					{
						if (currentDirection == 0)
						{
							if (!openedNodesStart.ContainsValue(neighborRecord.node.id))
								openedNodesStart.Add(neighborRecord, neighborRecord.node.id);
						}
						else
						{
							if (!openedNodesEnd.ContainsValue(neighborRecord.node.id))
								openedNodesEnd.Add(neighborRecord, neighborRecord.node.id);
						}

					}*/
					/*if (neighborRecord.category == NodeRecordCategory.CLOSED && cost < neighborRecord.costSoFar)
						neighborRecord.category = NodeRecordCategory.UNVISITED;*/
					if (neighborRecord.category != NodeRecordCategory.CLOSED && neighborRecord.category != NodeRecordCategory.OPEN)
					{

						if(currentDirection == 0)
                        {
							neighborRecord.costSoFar0 = cost;
							neighborRecord.category = NodeRecordCategory.OPEN;
							NodeRecord currentAux = openedNodesEnd.Keys[0];
							neighborRecord.estimatedTotalCost = neighborRecord.costSoFar0 + heuristic.estimateCostTwoNodes(neighborRecord.node, currentAux.node) + currentAux.costSoFar1;
							neighborRecord.connection0 = current;
							neighborRecord.direction = currentDirection;
							if (!openedNodesStart.ContainsValue(neighborRecord.node.id))
								openedNodesStart.Add(neighborRecord, neighborRecord.node.id);
						}
						else
                        {
							neighborRecord.costSoFar1 = cost;
							neighborRecord.category = NodeRecordCategory.OPEN;
							NodeRecord currentAux = openedNodesStart.Keys[0];
							neighborRecord.estimatedTotalCost = neighborRecord.costSoFar1 + heuristic.estimateCostTwoNodes(neighborRecord.node, currentAux.node) + currentAux.costSoFar0;
							neighborRecord.connection1 = current;
							neighborRecord.direction = currentDirection;
							if (!openedNodesEnd.ContainsValue(neighborRecord.node.id))
								openedNodesEnd.Add(neighborRecord, neighborRecord.node.id);
						}
					}
				}

				if (currentDirection == 0)
				{
					currentDirection = 1;
				}
				else
				{
					currentDirection = 0;
				}
			}
			
			if(startRecordEnd != null)
			{
				NodeRecord currentPathRecord = startRecordEnd;
				while (currentPathRecord.connection0 != null)
                {
					path.Add(currentPathRecord.node);
					currentPathRecord = currentPathRecord.connection0;
				}
				
				Debug.Log("Path0 found");
				found = 1;
			}
            else
            {
				Debug.Log("Path0 not found");
				found = 0;
			}

			path.Reverse();
			if (endRecordEnd != null && endRecordEnd.connection1 != null)
			{
				NodeRecord currentPathRecord = endRecordEnd.connection1;
				while (currentPathRecord.connection1 != null)
				{
					path.Add(currentPathRecord.node);
					currentPathRecord = currentPathRecord.connection1;
				}
				path.Add(currentPathRecord.node);
				Debug.Log("Path1 found");
				found = 1;
			}
			else
			{
				Debug.Log("Path1 not found");
				found = 0;
			}
			return path;
		}


    };

}