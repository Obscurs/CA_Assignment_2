﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PathFinding;

public class GridCell : Node
{
    public Vector2 position;
    public int id_aux;
    public GridCell(int id, int id2, Vector2 pos) : base(id)
    {
        id_aux = id2;
        position = pos;
    }

    public GridCell(GridCell cell):base(cell)
    {
        position = cell.position;
    }
}
