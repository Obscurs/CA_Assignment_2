﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using PathFinding;
public class gridController : MonoBehaviour
{
    public const int NUMCELLS_X = 20;
    public const int NUMCELLS_Z = 20;
    public const int SIZECELL = 2;
    public const int STARTPOS_X = 0;
    public const int STARTPOS_Z = 0;
    public Grid grid;
    public Grid_A_Star pathFinderA_Star;
    public Grid_A_Star_Bidirectional pathFinderA_Star_Bidirectional;
    public GameObject obstaclePefab;
    public int[,] obstaclesPositions = new int[NUMCELLS_X, NUMCELLS_Z];
    public bool inited = false;
    public List<GameObject> listObstacles = new List<GameObject>();
    void Awake()
    {
        //Random.seed = 42;
        int currObsId = 0;
        for (int i = 0; i < NUMCELLS_X; ++i)
        {
            for (int j = 0; j < NUMCELLS_Z; ++j)
            {
                if (i == 0 || i == NUMCELLS_X - 1 || j == 0 || j == NUMCELLS_Z - 1 || Random.Range(0, 9) < 2)
                {
                    obstaclesPositions[i, j] = currObsId;
                    GameObject currObs;
                    currObs = (GameObject)Instantiate(obstaclePefab, new Vector3(i * SIZECELL + STARTPOS_X, 0, j * SIZECELL + STARTPOS_Z), Quaternion.identity);
                    listObstacles.Add(currObs);
                    currObsId += 1;
                }
                else
                {
                    obstaclesPositions[i, j] = -1;
                }
            }
        }
        grid = new Grid(NUMCELLS_X, NUMCELLS_Z, SIZECELL, STARTPOS_X, STARTPOS_Z, obstaclesPositions);
        pathFinderA_Star = new Grid_A_Star();
        pathFinderA_Star_Bidirectional = new Grid_A_Star_Bidirectional();
        inited = true;
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public Vector2 GetRandomAvailableCell()
    {
        while(true)
        {
            int index_x = Random.Range(0, NUMCELLS_X - 1);
            int index_y = Random.Range(0, NUMCELLS_Z - 1);
            if (obstaclesPositions[index_x, index_y] == -1)
            {
                return GetPositionGivenIndices(index_x, index_y);
            }
        }
    }
    public Vector2 GetPositionGivenIndices(int index_x, int index_y)
    {
        return new Vector2(index_x * SIZECELL + STARTPOS_X, index_y * SIZECELL + STARTPOS_Z);
    }
    public GridCell getNodeGivenPosition(Vector2 position)
    {
        int index_x = (int)System.Math.Floor((position.x+ SIZECELL/2 - STARTPOS_X)/ SIZECELL);
        int index_y = (int)System.Math.Floor((position.y+ SIZECELL / 2 - STARTPOS_Z)/ SIZECELL);
        if (index_x >= NUMCELLS_X || index_y >= NUMCELLS_Z)
            Debug.LogError("ERROR: BAD INDEX");
        return grid.getNodeByIdAux(index_x * NUMCELLS_Z + index_y);

    }
    private void OnDrawGizmos()
    {
        /*Gizmos.color = Color.red;
        foreach (GridConnections gcs in grid.connections)
        {
            foreach(CellConnection gc in gcs.connections)
            {
                Gizmos.DrawLine(new Vector3(gc.fromNode.position.x, 2, gc.fromNode.position.y), new Vector3(gc.toNode.position.x, 1, gc.toNode.position.y));
                
            }
            
        }
        */
    }
}
