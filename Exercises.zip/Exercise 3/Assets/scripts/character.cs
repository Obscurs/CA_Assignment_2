﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PathFinding;
public class character : MonoBehaviour
{
    

    Animator anim;
    Rigidbody rb;
    // Start is called before the first frame update
    //bool up = false, down = false, left= false, right = false;
    Vector3 currentVelocity = new Vector3(0, 0, 0);
    const float MAX_SPEED = 10.0f;
    public Vector2 currentGoal;
    public bool goalAssigned = false;
    List<GridCell> goalSteps;
    List<Collider> frontObstacles;
    List<Vector3> avoidLines;
    List<Vector3> avoidPoses;
    public GameObject walls;
    public GameObject crowd;

    public bool seekTowards;
    public bool usingBidirectAStar;

    public bool debug_enabled;

    GameObject target = null;
    void Awake()
    {
        usingBidirectAStar = false;
        seekTowards = true;

        walls = GameObject.Find("Walls");
        crowd = GameObject.Find("Crowd");
        goalSteps = new List<GridCell>();
        frontObstacles = new List<Collider>();
        avoidLines = new List<Vector3>();
        avoidPoses = new List<Vector3>();
        debug_enabled = false;
      
}
    void Start()
    {
        
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody>();

    }

    // Update is called once per frame
    void Update()
    {


    }


    void FixedUpdate()
    {
        Vector3 steering_force_seek = new Vector3(0, 0, 0);
        Vector3 steering_force_evade = new Vector3(0, 0, 0);
        Vector3 obstacle_avoid_force = new Vector3(0, 0, 0);
        Vector3 defalt_force = new Vector3(0, 0, 0);
        Vector3 auxRBPos = new Vector3(rb.position.x, 0, rb.position.z);
        if (goalAssigned)
        {
            Vector3 auxGoalPos = new Vector3(currentGoal.x, 0, currentGoal.y);
            float aux_dist = Vector3.Distance(auxGoalPos, auxRBPos);
            
            if (aux_dist < 1.5)
                goalAssigned = false;
 
            steering_force_seek = (auxGoalPos - auxRBPos).normalized * MAX_SPEED - currentVelocity;

        }
        else
        {
            assignNewGoal();
        }

        
        //print("vel: " + velx + " " + vely);
        Vector3 totalForce = steering_force_seek*1;
        totalForce = Truncate(totalForce, 100);
        Vector3 acceleration = totalForce / rb.mass;
        currentVelocity += acceleration * Time.deltaTime;
        currentVelocity = Truncate(currentVelocity, MAX_SPEED);
        rb.position += currentVelocity * Time.deltaTime;

        if (currentVelocity != Vector3.zero)
        {
            transform.rotation = Quaternion.LookRotation(currentVelocity, Vector3.up);
        }

        anim.SetFloat("velx", currentVelocity.magnitude/8);
    }

    Vector3 Truncate(Vector3 v, float max)
    {
        float size = Mathf.Min(v.magnitude, max);
        return v.normalized * size;
    }

    public void changePathFinder()
    {
        usingBidirectAStar = !usingBidirectAStar;
    }

    void assignNewGoal()
    {
        bool pursuer_evader_assigned = false;
        while(goalSteps.Count == 0)
        {
            goalSteps.Clear();
            gridController gcc = walls.GetComponent<gridController>();
            Grid grid = walls.GetComponent<gridController>().grid;
            GridCell start = walls.GetComponent<gridController>().getNodeGivenPosition(new Vector2(rb.position.x, rb.position.z));
            Vector2 endPos;
            
            endPos= walls.GetComponent<gridController>().GetRandomAvailableCell();
            GridCell end = walls.GetComponent<gridController>().getNodeGivenPosition(endPos);
            GridHeuristic hr = new GridHeuristic(end);
            int found = -1;
            if(usingBidirectAStar)
                goalSteps = walls.GetComponent<gridController>().pathFinderA_Star_Bidirectional.findpath(grid, start, end, hr, ref found);
            else
                goalSteps = walls.GetComponent<gridController>().pathFinderA_Star.findpath(grid, start, end, hr, ref found);

        }
        if(goalSteps.Count > 0)
        {
            currentGoal = goalSteps[0].position;
            goalSteps.RemoveAt(0);
            goalAssigned = true;
        }
        
    }


    void OnTriggerEnter(Collider other)
    {
        //Debug.Log("Obstacle detected in front");
        frontObstacles.Add(other);
            //Destroy(other.gameObject);
    }
    void OnTriggerExit(Collider other)
    {
        //Debug.Log("Obstacle detected in front");
        frontObstacles.Remove(other);
        //Destroy(other.gameObject);
    }


    private void OnDrawGizmos()
    {
        if(debug_enabled)
        {
            Gizmos.color = Color.red;
            foreach (GridCell gc in goalSteps)
            {
                Gizmos.DrawSphere(new Vector3(gc.position.x, 1, gc.position.y), 0.5f);
            }
            Gizmos.color = Color.blue;

            for (int i = 0; i < avoidPoses.Count; ++i)
            {
                Gizmos.DrawSphere(new Vector3(avoidPoses[i].x, 2, avoidPoses[i].z), 0.5f);
                Gizmos.DrawLine(new Vector3(avoidPoses[i].x, 2, avoidPoses[i].z), new Vector3(avoidLines[i].x, 2, avoidLines[i].z));

            }


            Gizmos.color = Color.green;
            Gizmos.DrawSphere(new Vector3(currentGoal.x, 1, currentGoal.y), 0.6f);
            Gizmos.DrawLine(rb.transform.forward + rb.transform.position, rb.transform.position);
        }

    }
}
