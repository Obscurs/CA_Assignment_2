﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PathFinding;
public class GridConnections : NodeConnections<GridCell, CellConnection>
{
    public GridConnections() : base()
    {

    }
}
