﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PathFinding;
public class Grid_A_Star : A_Star<GridCell,CellConnection,GridConnections,Grid,GridHeuristic>
{
    public Grid_A_Star():base(0,0,0)
    {

    }
    // Start is called before the first frame update

}
