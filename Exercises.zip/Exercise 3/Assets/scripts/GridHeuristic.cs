﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PathFinding;
public class GridHeuristic : Heuristic<GridCell>
{
    public GridHeuristic(GridCell goal) : base(goal)
    {

    }

    public override float estimateCost(GridCell fromNode) 
    {
        return Vector2.Distance(fromNode.position, goalNode.position);
    }

    public override float estimateCostTwoNodes(GridCell fromNode, GridCell toNode)
    {
        return Vector2.Distance(fromNode.position, toNode.position);
    }
    public override bool goalReached(GridCell fromNode)
    {
        return fromNode == goalNode;
    }
}
