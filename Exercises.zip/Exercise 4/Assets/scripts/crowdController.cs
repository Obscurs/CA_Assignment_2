﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class crowdController : MonoBehaviour
{
    public GameObject agent;
    public GameObject walls;
    public const int N_NORMAL_AGENTS = 3;
    public const int N_TARGET_AGENTS = 1;
    public const int N_EVADER_AGENTS = 1;
    public const int N_PURSUER_AGENTS = 1;
    public List<GameObject> agentListNormal = new List<GameObject>();
    public List<GameObject> agentListTarget = new List<GameObject>();
    public List<GameObject> agentListEvader = new List<GameObject>();
    public List<GameObject> agentListPursuer = new List<GameObject>();
    void Awake()
    {
        walls = GameObject.Find("Walls");

    }
    // Start is called before the first frame update
    void Start()
    {
        if (!walls.GetComponent<gridController>().inited)
            Debug.LogError("Error: Grid is not inited");
        List<Vector2> positions = new List<Vector2>();
        int countInstantiated = 0;
        while(countInstantiated < N_NORMAL_AGENTS)
        {
            Vector2 newPos = walls.GetComponent<gridController>().GetRandomAvailableCell();
            if(!positions.Contains(newPos))
            {
                positions.Add(newPos);
                GameObject currAgent;
                currAgent = Instantiate(agent, new Vector3(newPos.x, 0, newPos.y), Quaternion.identity);
                agentListNormal.Add(currAgent);
                countInstantiated += 1;
            }
        }
        countInstantiated = 0;
        while (countInstantiated < N_TARGET_AGENTS)
        {
            Vector2 newPos = walls.GetComponent<gridController>().GetRandomAvailableCell();
            if (!positions.Contains(newPos))
            {
                positions.Add(newPos);
                GameObject currAgent;
                currAgent = Instantiate(agent, new Vector3(newPos.x, 0, newPos.y), Quaternion.identity);
                currAgent.GetComponent<character>().SetTarget();
                agentListTarget.Add(currAgent);
                countInstantiated += 1;
            }
        }
        countInstantiated = 0;
        while (countInstantiated < N_EVADER_AGENTS)
        {
            Vector2 newPos = walls.GetComponent<gridController>().GetRandomAvailableCell();
            if (!positions.Contains(newPos))
            {
                positions.Add(newPos);
                GameObject currAgent;
                currAgent = Instantiate(agent, new Vector3(newPos.x, 0, newPos.y), Quaternion.identity);
                currAgent.GetComponent<character>().SetEvader();
                agentListEvader.Add(currAgent);
                countInstantiated += 1;
            }
        }
        countInstantiated = 0;
        while (countInstantiated < N_PURSUER_AGENTS)
        {
            Vector2 newPos = walls.GetComponent<gridController>().GetRandomAvailableCell();
            if (!positions.Contains(newPos))
            {
                positions.Add(newPos);
                GameObject currAgent;
                currAgent = Instantiate(agent, new Vector3(newPos.x, 0, newPos.y), Quaternion.identity);
                currAgent.GetComponent<character>().SetPursuer();
                agentListPursuer.Add(currAgent);
                countInstantiated += 1;
            }
        }
        /*
        for(int i=0; i< 10; ++i)
        {
            for (int j = 0; j < 10; ++j)
            {
                Instantiate(agent, new Vector3(i * 2, 0, j * 2), Quaternion.identity);

            }
        }*/
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public GameObject GetRandomTarget()
    {
        return agentListTarget[Random.Range(0, N_TARGET_AGENTS - 1)];
    }
}
