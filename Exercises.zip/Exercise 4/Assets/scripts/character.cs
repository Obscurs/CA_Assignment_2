﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PathFinding;
public class character : MonoBehaviour
{
    

    Animator anim;
    Rigidbody rb;
    // Start is called before the first frame update
    //bool up = false, down = false, left= false, right = false;
    Vector3 currentVelocity = new Vector3(0, 0, 0);
    const float MAX_SPEED = 10.0f;
    public Vector2 currentGoal;
    public bool goalAssigned = false;
    List<GridCell> goalSteps;
    List<Collider> frontObstacles;
    List<Vector3> avoidLines;
    List<Vector3> avoidPoses;
    public GameObject walls;
    public GameObject crowd;

    public bool pursuer;
    public bool evader;
    public bool avoidObstacles;
    public bool seekTowards;
    public bool usingBidirectAStar;
    public float influence_seek;
    public float influence_avoid;
    public float influence_evade;
    public bool role_has_changed;
    public bool i_am_target;
    public bool debug_enabled;
    public float timer_evader_update_target;

    GameObject target = null;
    void Awake()
    {
        usingBidirectAStar = false;
        seekTowards = true;
        avoidObstacles = true;
        evader = false;
        pursuer = false;
        walls = GameObject.Find("Walls");
        crowd = GameObject.Find("Crowd");
        goalSteps = new List<GridCell>();
        frontObstacles = new List<Collider>();
        avoidLines = new List<Vector3>();
        avoidPoses = new List<Vector3>();
        debug_enabled = false;
        influence_seek = 1;
        influence_evade = 1;
        influence_avoid = 0.7f;
        role_has_changed = true;
        i_am_target = false;
        timer_evader_update_target = 0.0f;
}
    void Start()
    {
        
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody>();

        GameObject mesh = transform.Find("Mesh_Male").gameObject;
        SkinnedMeshRenderer skined = mesh.GetComponent<SkinnedMeshRenderer>();
        //skined.material.SetColor(1, Color.red);
        skined.material.color = Color.red;
    }

    // Update is called once per frame
    void Update()
    {
        if(role_has_changed)
        {
            GameObject mesh = transform.Find("Mesh_Male").gameObject;
            SkinnedMeshRenderer skined = mesh.GetComponent<SkinnedMeshRenderer>();
            if (pursuer)
                skined.material.color = Color.yellow;
            else if (evader)
                skined.material.color = Color.blue;
            else if (i_am_target)
                skined.material.color = Color.red;
            else
                skined.material.color = new Color(0.632f, 0.632f, 0.632f);
            role_has_changed = false;
        }
        if (timer_evader_update_target > 0)
            timer_evader_update_target -= Time.deltaTime;



    }

    public void SetTarget()
    {
        i_am_target = true;
        role_has_changed = true;
    }

    public void SetEvader()
    {
        evader = true;
        role_has_changed = true;
    }
    public void SetPursuer()
    {
        pursuer = true;
        role_has_changed = true;
    }
    void FixedUpdate()
    {
        Vector3 steering_force_seek = new Vector3(0, 0, 0);
        Vector3 steering_force_evade = new Vector3(0, 0, 0);
        Vector3 obstacle_avoid_force = new Vector3(0, 0, 0);
        Vector3 defalt_force = new Vector3(0, 0, 0);
        Vector3 auxRBPos = new Vector3(rb.position.x, 0, rb.position.z);
        if (goalAssigned)
        {
            Vector3 auxGoalPos = new Vector3(currentGoal.x, 0, currentGoal.y);
            float aux_dist = Vector3.Distance(auxGoalPos, auxRBPos);
            
            if (aux_dist < 1.5)
                goalAssigned = false;
            if(evader && timer_evader_update_target <= 0)
            {
                goalAssigned = false;
                timer_evader_update_target = 0.5f;
            }
            /*else
            {*/


            if(evader)
                steering_force_evade = -1*(auxGoalPos - auxRBPos).normalized * MAX_SPEED - currentVelocity;
            else
                steering_force_seek = (auxGoalPos - auxRBPos).normalized * MAX_SPEED - currentVelocity;

                
                
                //rb.position = new Vector3(v3Position.x + direction_x * SPEED, 0, v3Position.z +direction_z * SPEED);
                //rb.AddForce(direction_x * SPEED, 0, direction_z * SPEED);
            //}

        }
        else
        {
            assignNewGoal();
        }

        if(avoidObstacles)
        {
            avoidLines.Clear(); //DEBUG
            avoidPoses.Clear(); //DEBUG
            Collider nearest_obstacle = null;
            float nearest_distance = -1;
            for (int i = 0; i < frontObstacles.Count; ++i)
            {

                Collider obs = frontObstacles[i];
                //Debug.Log(rb.transform.forward + " " + rb.transform.forward.magnitude);
                Vector3 auxObsPos_ = new Vector3(obs.transform.position.x, 0, obs.transform.position.z);
                float distance_ = Mathf.Min(Vector3.Distance(auxObsPos_, auxRBPos), 6);
                if (distance_ < nearest_distance || nearest_distance == -1)
                {
                    nearest_obstacle = obs;
                    nearest_distance = distance_;
                }
            }
            if(nearest_obstacle != null)
            {
                Vector3 auxObsPos = new Vector3(nearest_obstacle.transform.position.x, 0, nearest_obstacle.transform.position.z);
                float distance = Mathf.Min(Vector3.Distance(auxObsPos, auxRBPos), 6);

                float influence = 6 - distance;
                Vector3 projectionVec = Vector3.Dot(rb.transform.forward, auxObsPos - auxRBPos) * rb.transform.forward;
                Vector3 avoidDirection = (auxObsPos - auxRBPos - projectionVec).normalized * -1;
                //Vector3 avoidDirection = (projectionVec- auxRBPos- auxObsPos).normalized;
                Vector3 avoidForce = (avoidDirection * influence);
                obstacle_avoid_force += avoidForce - currentVelocity;
                avoidLines.Add(avoidDirection * influence + auxObsPos);
                avoidPoses.Add(auxObsPos);
            }
            
            

            /*for (int i=0; i < frontObstacles.Count; ++i)
            {
                Collider obs = frontObstacles[i];
                Debug.Log(rb.transform.forward + " " + rb.transform.forward.magnitude);
                Vector3 auxObsPos = new Vector3(obs.transform.position.x, 0, obs.transform.position.z);
                float distance = Mathf.Min(Vector3.Distance(auxObsPos, auxRBPos),6);
                float influence = 6 - distance;
                Vector3 projectionVec = Vector3.Dot(rb.transform.forward, auxObsPos - auxRBPos) * rb.transform.forward;
                Vector3 avoidDirection = (auxObsPos- auxRBPos- projectionVec).normalized*-1;
                //Vector3 avoidDirection = (projectionVec- auxRBPos- auxObsPos).normalized;
                Vector3 avoidForce = (avoidDirection * influence + auxRBPos);
                obstacle_avoid_force += avoidForce - currentVelocity;
                avoidLines.Add(avoidDirection * influence + auxObsPos);
                avoidPoses.Add(auxObsPos);
            }*/
        }
        //print("vel: " + velx + " " + vely);
        Vector3 totalForce = steering_force_seek*influence_seek + defalt_force+ obstacle_avoid_force*influence_avoid+ steering_force_evade* influence_evade;
        totalForce = Truncate(totalForce, 100);
        Vector3 acceleration = totalForce / rb.mass;
        currentVelocity += acceleration * Time.deltaTime;
        currentVelocity = Truncate(currentVelocity, MAX_SPEED);
        rb.position += currentVelocity * Time.deltaTime;

        if (currentVelocity != Vector3.zero)
        {
            transform.rotation = Quaternion.LookRotation(currentVelocity, Vector3.up);
        }

        anim.SetFloat("velx", currentVelocity.magnitude/8);
    }

    Vector3 Truncate(Vector3 v, float max)
    {
        float size = Mathf.Min(v.magnitude, max);
        return v.normalized * size;
    }
    void assignTarget()
    {
        crowdController cc = crowd.GetComponent<crowdController>();
        target = cc.GetRandomTarget();
    }
    void assignNewGoal()
    {
        bool pursuer_evader_assigned = false;
        while((goalSteps.Count == 0 && !pursuer && !evader) || (!pursuer_evader_assigned && (pursuer || evader)))
        {
            goalSteps.Clear();
            gridController gcc = walls.GetComponent<gridController>();
            Grid grid = walls.GetComponent<gridController>().grid;
            GridCell start = walls.GetComponent<gridController>().getNodeGivenPosition(new Vector2(rb.position.x, rb.position.z));
            Vector2 endPos;
            if(pursuer || evader)
            {
                pursuer_evader_assigned = true;
                if (target == null)
                    assignTarget();
                if (target != null)
                    endPos = new Vector2(target.transform.position.x, target.transform.position.z);
                else
                    return;
            }
            else
                endPos= walls.GetComponent<gridController>().GetRandomAvailableCell();
            GridCell end = walls.GetComponent<gridController>().getNodeGivenPosition(endPos);
            GridHeuristic hr = new GridHeuristic(end);
            int found = -1;
            if(usingBidirectAStar)
                goalSteps = walls.GetComponent<gridController>().pathFinderA_Star_Bidirectional.findpath(grid, start, end, hr, ref found);
            else
                goalSteps = walls.GetComponent<gridController>().pathFinderA_Star.findpath(grid, start, end, hr, ref found);
            if (pursuer && goalSteps.Count == 0)
                assignTarget();
        }
        if(goalSteps.Count > 0)
        {
            currentGoal = goalSteps[0].position;
            goalSteps.RemoveAt(0);
            goalAssigned = true;
        }
        
    }


    void OnTriggerEnter(Collider other)
    {
        //Debug.Log("Obstacle detected in front");
        frontObstacles.Add(other);
            //Destroy(other.gameObject);
    }
    void OnTriggerExit(Collider other)
    {
        //Debug.Log("Obstacle detected in front");
        frontObstacles.Remove(other);
        //Destroy(other.gameObject);
    }


    private void OnDrawGizmos()
    {
        if(debug_enabled)
        {
            Gizmos.color = Color.red;
            foreach (GridCell gc in goalSteps)
            {
                Gizmos.DrawSphere(new Vector3(gc.position.x, 1, gc.position.y), 0.5f);
            }
            Gizmos.color = Color.blue;

            for (int i = 0; i < avoidPoses.Count; ++i)
            {
                Gizmos.DrawSphere(new Vector3(avoidPoses[i].x, 2, avoidPoses[i].z), 0.5f);
                Gizmos.DrawLine(new Vector3(avoidPoses[i].x, 2, avoidPoses[i].z), new Vector3(avoidLines[i].x, 2, avoidLines[i].z));

            }


            Gizmos.color = Color.green;
            Gizmos.DrawSphere(new Vector3(currentGoal.x, 1, currentGoal.y), 0.6f);
            Gizmos.DrawLine(rb.transform.forward + rb.transform.position, rb.transform.position);
        }

    }
}
