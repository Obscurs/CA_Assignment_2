﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class character : MonoBehaviour
{

    Animator anim;
    Rigidbody rb;
    // Start is called before the first frame update
    //bool up = false, down = false, left= false, right = false;
    Vector3 currentVelocity = new Vector3(0, 0, 0);

    //public Vector2 currentGoal;



    public bool debug_enabled;

    bool W_key;
    bool A_key;
    bool D_key;
    float inc_w;
    float inc_ad;
    GameObject target = null;
    void Awake()
    {
        W_key = false;
        A_key = false;
        D_key = false;
        inc_w = 0;
        inc_ad = 0;
        anim = GetComponent<Animator>();
        


    }
    void Start()
    {
        debug_enabled = true;



    }

    void Update()
    {
        



        if (Input.GetKeyDown("w"))
        {
            W_key = true;
        }
        if (Input.GetKeyUp("w"))
        {
            W_key = false;
        }
        if (Input.GetKeyDown("a"))
        {
            A_key = true;
        }
        if (Input.GetKeyUp("a"))
        {
            A_key = false;
        }
        if (Input.GetKeyDown("d"))
        {
            D_key = true;
        }
        if (Input.GetKeyUp("d"))
        {
            D_key = false;
        }

        if(W_key)
        {
            inc_w = Mathf.Min(1.0f, inc_w + Time.deltaTime);
        }
        else
        {
            inc_w = Mathf.Max(0.0f, inc_w - Time.deltaTime*2);
        }
        if (A_key)
        {
            float multiplier = 1;
            if (inc_ad > 0)
                multiplier = 2;
            inc_ad = Mathf.Max(-1.0f, inc_ad - Time.deltaTime* multiplier);
        }
        else if(D_key)
        {
            float multiplier = 1;
            if (inc_ad < 0)
                multiplier = 2;
            inc_ad = Mathf.Min(1.0f, inc_ad + Time.deltaTime* multiplier);
        }
        else
        {
            if(inc_ad < 0)
            {
                inc_ad = Mathf.Min(0.0f, inc_ad + Time.deltaTime);
            }
            else
            {
                inc_ad = Mathf.Max(0.0f, inc_ad - Time.deltaTime);
            }
        }

        transform.Rotate(new Vector3(0, Time.deltaTime * inc_ad*60, 0));
        transform.position += transform.forward * Time.deltaTime * inc_w*5;
        Debug.Log("ad: " + inc_ad + " w: " + inc_w);
        anim.SetFloat("turn_sides", inc_ad);
        anim.SetFloat("forward", inc_w);
        //anim.SetFloat("turn_sides", 0);
        //anim.SetFloat("forward", 1);
        //Debug.Log("state: " + currentAnimStep + " time: " + anim.GetCurrentAnimatorStateInfo(0).normalizedTime);

    }
    

    



   
}
