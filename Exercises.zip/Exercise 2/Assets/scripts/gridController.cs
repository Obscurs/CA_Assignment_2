﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gridController : MonoBehaviour
{
    public const int NUMCELLS_X = 20;
    public const int NUMCELLS_Z = 20;
    public const int SIZECELL = 2;
    public const int STARTPOS_X = 0;
    public const int STARTPOS_Z = 0;

    public bool inited = false;
    void Awake()
    {

        inited = true;
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public Vector2 GetRandomAvailableCell()
    {
        while(true)
        {
            int index_x = Random.Range(0, NUMCELLS_X - 1);
            int index_y = Random.Range(0, NUMCELLS_Z - 1);

            return GetPositionGivenIndices(index_x, index_y);
            
        }
    }
    public Vector2 GetPositionGivenIndices(int index_x, int index_y)
    {
        return new Vector2(index_x * SIZECELL + STARTPOS_X, index_y * SIZECELL + STARTPOS_Z);
    }

    private void OnDrawGizmos()
    {
        /*Gizmos.color = Color.red;
        foreach (GridConnections gcs in grid.connections)
        {
            foreach(CellConnection gc in gcs.connections)
            {
                Gizmos.DrawLine(new Vector3(gc.fromNode.position.x, 2, gc.fromNode.position.y), new Vector3(gc.toNode.position.x, 1, gc.toNode.position.y));
                
            }
            
        }
        */
    }
}
