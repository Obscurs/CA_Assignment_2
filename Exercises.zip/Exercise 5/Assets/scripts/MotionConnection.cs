﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PathFinding;
public class MotionConnection : Connection<MotionNode>
{
    public MotionConnection(MotionNode from, MotionNode to):base(from,to)
    {
        setCost(Vector3.Distance(fromNode.position, to.position));
    }
}
