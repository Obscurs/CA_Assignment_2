﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PathFinding;
public class MotionNodeConnections : NodeConnections<MotionNode, MotionConnection>
{
    public MotionNodeConnections() : base()
    {

    }
}
