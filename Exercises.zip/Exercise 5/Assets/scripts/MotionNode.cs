﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PathFinding;

public class MotionNode : Node
{
    public Vector3 position;
    public Quaternion rotation;
    public int id_enum;
    public MotionNode(int id,int id_aux, Vector3 pos, Quaternion rot) : base(id)
    {
        position = pos;
        rotation = rot;
        id_enum = id_aux;
    }

    public MotionNode(MotionNode cell):base(cell)
    {
        position = cell.position;
        rotation = cell.rotation;
        id_enum = cell.id_enum;
    }
}
