﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PathFinding;
public class Motion_A_Star : A_Star<MotionNode,MotionConnection, MotionNodeConnections, MotionGraph,MotionHeuristic>
{
    public Motion_A_Star():base(0,0,0)
    {

    }
    // Start is called before the first frame update

}
