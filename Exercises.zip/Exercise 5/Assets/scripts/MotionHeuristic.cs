﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PathFinding;
public class MotionHeuristic : Heuristic<MotionNode>
{
    public MotionHeuristic(MotionNode goal) : base(goal)
    {

    }

    public override float estimateCost(MotionNode fromNode) 
    {
        return Vector3.Distance(fromNode.position, goalNode.position)+1;
    }

    public override float estimateCostTwoNodes(MotionNode fromNode, MotionNode toNode)
    {
        return Vector3.Distance(fromNode.position, toNode.position);
    }
    public override bool goalReached(MotionNode fromNode)
    {
        //return fromNode == goalNode;
        return Vector3.Distance(fromNode.position, goalNode.position) < 2;
    }
}
