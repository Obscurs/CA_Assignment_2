﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PathFinding;
public class MotionGraph : Graph<MotionNode, MotionConnection,MotionNodeConnections>
{
    public List<MotionNode> nodes;
    public List<MotionNodeConnections> connections;
    List<Quaternion> _rotations;
    List<Vector3> _translations;
    void expandNode(int indexToExpand)
    {
        MotionNode currNode = nodes[indexToExpand];
        MotionNodeConnections currConnections = connections[indexToExpand];
        for(int i=1; i < _translations.Count; ++i)
        {
            Matrix4x4 matrix = Matrix4x4.TRS(Vector3.zero, currNode.rotation, Vector3.one);
            Vector3 newPos = matrix.MultiplyPoint(_translations[i]);
            MotionNode newNode = new MotionNode(nodes.Count, i, newPos + currNode.position, _rotations[i]* currNode.rotation);
            currConnections.Add(new MotionConnection(currNode, newNode));
            nodes.Add(newNode);
            connections.Add(new MotionNodeConnections());
        }
  
    }
    public void ResetGraph(Vector3 startPosition, Quaternion startRotation)
    {
        nodes.Clear();
        connections.Clear();

        nodes = new List<MotionNode>();
        connections = new List<MotionNodeConnections>();
        //int currentNodeIndex = 0;
        nodes.Add(new MotionNode(0,0, startPosition, startRotation));
        connections.Add(new MotionNodeConnections());
        expandNode(0);
    }
    public MotionGraph(List<Quaternion> rotations, List<Vector3> translations, Vector3 startPosition, Quaternion startRotation) : base()
    {
        nodes = new List<MotionNode>();
        connections = new List<MotionNodeConnections>();
        _rotations = rotations;
        _translations = translations;
        ResetGraph(startPosition, startRotation);
        /*
        //CREATE NODES
        int currentNodeIndex = 0;
        for (int i = 0; i < numCellsX; ++i)
        {
            for (int j = 0; j < numCellsZ; ++j)
            {
                if (obstaclesPositions[i, j] == -1)
                {
                    nodes.Add(new GridCell(currentNodeIndex,i * numCellsZ + j, new Vector2(i* sizeCell+ startPosX, j* sizeCell + startPosY)));
                    currentNodeIndex += 1;
                    connections.Add(new GridConnections());
                    //Debug.Log("Cell created: " + i + " " + j + " " + i * numCellsZ + j);
                }
            }
        }
        //CREATE CONNECTIONS
        currentNodeIndex = 0;
        for (int i = 0; i < numCellsX; ++i)
        {
            for (int j = 0; j < numCellsZ; ++j)
            {
                if (obstaclesPositions[i, j] == -1)
                {
                    for (int aux_i = i - 1; aux_i <= i + 1; ++aux_i)
                    {
                        for (int aux_j = j - 1; aux_j <= j + 1; ++aux_j)
                        {
                            if (aux_i >= 0 && aux_j >= 0 && aux_i < numCellsX && aux_j < numCellsZ && (aux_i != i || aux_j != j) && obstaclesPositions[aux_i, aux_j] == -1)
                            {
                                GridCell auxCell = getNodeByIdAux(aux_i * numCellsZ + aux_j);
                                if(auxCell == null)
                                {
                                    Debug.LogError("Cell not found: " + aux_i + " " + aux_j +" "+ aux_i * numCellsZ + aux_j);
                                }
                                bool valid = true;
                                //check corners are accessible
                                if((aux_i == i - 1 && aux_j == j - 1) || (aux_i == i + 1 && aux_j == j + 1) || (aux_i == i + 1 && aux_j == j - 1) || (aux_i == i - 1 && aux_j == j + 1))
                                {
                                    if (obstaclesPositions[i, aux_j] != -1 && obstaclesPositions[aux_i, j] != -1)
                                        valid = false;
                                }
                                if(valid)
                                    connections[currentNodeIndex].Add(new CellConnection(nodes[currentNodeIndex], auxCell));
                                //Debug.Log("connection created for node: " + i * numCellsZ + j);
                            }
                        }
                    }

                    currentNodeIndex++;
                }
            }
        }
        */
    }
    public MotionNodeConnections getConnections(int fromNodeIndex)
    {
        if (connections[fromNodeIndex].connections.Count == 0)
            expandNode(fromNodeIndex);
        return connections[fromNodeIndex];
    }
    public override MotionNodeConnections getConnections(MotionNode fromNode)
    {
        return getConnections(fromNode.getId());
    }
    /*
    public MotionNode getNodeByIdAux(int id)
    {
        foreach(GridCell gc in nodes)
        {
            if (gc.id_aux == id)
                return gc;
        }
        return null;
    }
    */
}
