﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PathFinding;
using System.Linq;

public class character : MonoBehaviour
{
    public enum animStates { IDLE, WALK, TURN_L, TURN_R, NONE };
    float MAX_DIST_X = 20;
    float MAX_DIST_Y = 20;
    Animator anim;
    Rigidbody rb;
    // Start is called before the first frame update
    //bool up = false, down = false, left= false, right = false;
    Vector3 currentVelocity = new Vector3(0, 0, 0);
    const float MAX_SPEED = 5.0f;
    //public Vector2 currentGoal;
    public bool goalAssigned = false;
    public MotionGraph graph;
    public Motion_A_Star pathFinderA_Star;
    MotionNode currEndNode;
    List<animStates> goalSteps;
    List<MotionNode> currListNodes = new List<MotionNode>();
    animStates currentAnimStep;
    //List<Vector3> avoidLines;
    //List<Vector3> avoidPoses;
    //public GameObject walls;
    //public GameObject crowd;

    public List<Quaternion> rotationAnimations = new List<Quaternion>();
    public List<Vector3> positionAnimations = new List<Vector3>();

    public bool debug_enabled;

    GameObject target = null;
    void Awake()
    {
        anim = GetComponent<Animator>();
        anim.SetFloat("Blend", 0.5f);
        //rb = GetComponent<Rigidbody>();
        //walls = GameObject.Find("Walls");
        //crowd = GameObject.Find("Crowd");
        goalSteps = new List<animStates>();
        //goalSteps.Add(animStates.IDLE);
        /*goalSteps.Add(animStates.WALK);
        goalSteps.Add(animStates.TURN_L);
        goalSteps.Add(animStates.WALK);
        goalSteps.Add(animStates.TURN_R);
        goalSteps.Add(animStates.WALK);
        goalSteps.Add(animStates.IDLE);*/
        //avoidLines = new List<Vector3>();
        //avoidPoses = new List<Vector3>();
        debug_enabled = false;
        currentAnimStep = animStates.NONE;
        Vector3 oldPosition = transform.position;
        Quaternion oldRotation = transform.rotation;
        for(int i = 0; i < (int)animStates.NONE; ++ i)
        {
            transform.position = new Vector3(0, 0, 0);
            transform.rotation = new Quaternion(0, 0, 0, 1);
            anim.Play(GetAnimationName((animStates)i), 0, 0);
            anim.Update(0);

            anim.Play(GetAnimationName((animStates)i), 0, 1);
            float lenght = anim.GetCurrentAnimatorStateInfo(0).length;
            anim.Update(lenght);
            Quaternion newRot = transform.rotation;
            Vector3 newPos = transform.position;
            rotationAnimations.Add(newRot);
            positionAnimations.Add(newPos);
        }
        transform.position = oldPosition;
        transform.rotation = oldRotation;

        graph = new MotionGraph(rotationAnimations, positionAnimations, transform.position, transform.rotation);
        pathFinderA_Star = new Motion_A_Star();

    }
    void Start()
    {
        debug_enabled = true;



    }
    /*void OnAnimatorMove()
    {
        Animator animator = GetComponent<Animator>();

        if (animator)
        {
            Vector3 newPosition = transform.position;
            newPosition.x += animator.GetFloat("Runspeed") * Time.deltaTime;
            transform.position = newPosition;
        }
    }*/
    // Update is called once per frame
    void Update()
    {
        
        if(currentAnimStep == animStates.NONE && goalSteps.Count() > 0)
        {
            currentAnimStep = goalSteps[0];
            if(currListNodes.Count() > 0)
                currListNodes.RemoveAt(0);
            goalSteps.RemoveAt(0);
            
            anim.Play(GetAnimationName(currentAnimStep),0,0);
            anim.Update(0);
            
        }

        if (anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 1)
        {
            anim.Update(0);
            currentAnimStep = animStates.NONE;
        }
            

        if (currentAnimStep == animStates.NONE && goalSteps.Count == 0)
            assignNewGoal();



        //Debug.Log("state: " + currentAnimStep + " time: " + anim.GetCurrentAnimatorStateInfo(0).normalizedTime);

    }
    string GetAnimationName(animStates state)
    {
        switch(state)
        {
            case animStates.IDLE:
                return "Idle";
                break;
            case animStates.WALK:
                return "Walk";
                break;
            case animStates.TURN_L:
                return "TurnLeft";
                break;
            case animStates.TURN_R:
                return "TurnRight";
                break;
            case animStates.NONE:
                return "none";
                break;

        }
        return "error";
    }

    void FixedUpdate()
    {
        /*
        Vector3 steering_force_seek = new Vector3(0, 0, 0);
        Vector3 steering_force_evade = new Vector3(0, 0, 0);
        Vector3 obstacle_avoid_force = new Vector3(0, 0, 0);
        Vector3 defalt_force = new Vector3(0, 0, 0);
        Vector3 auxRBPos = new Vector3(rb.position.x, 0, rb.position.z);
        if (goalAssigned)
        {
            Vector3 auxGoalPos = new Vector3(currentGoal.x, 0, currentGoal.y);
            float aux_dist = Vector3.Distance(auxGoalPos, auxRBPos);
            
            if (aux_dist < 1.5)
                goalAssigned = false;
            if(evader && timer_evader_update_target <= 0)
            {
                goalAssigned = false;
                timer_evader_update_target = 0.5f;
            }



            if(evader)
                steering_force_evade = -1*(auxGoalPos - auxRBPos).normalized * MAX_SPEED - currentVelocity;
            else
                steering_force_seek = (auxGoalPos - auxRBPos).normalized * MAX_SPEED - currentVelocity;

                
                
                //rb.position = new Vector3(v3Position.x + direction_x * SPEED, 0, v3Position.z +direction_z * SPEED);
                //rb.AddForce(direction_x * SPEED, 0, direction_z * SPEED);
            //}

        }
        else
        {
            assignNewGoal();
        }

        if(avoidObstacles)
        {
            avoidLines.Clear(); //DEBUG
            avoidPoses.Clear(); //DEBUG
            Collider nearest_obstacle = null;
            float nearest_distance = -1;
            for (int i = 0; i < frontObstacles.Count; ++i)
            {

                Collider obs = frontObstacles[i];
                //Debug.Log(rb.transform.forward + " " + rb.transform.forward.magnitude);
                Vector3 auxObsPos_ = new Vector3(obs.transform.position.x, 0, obs.transform.position.z);
                float distance_ = Mathf.Min(Vector3.Distance(auxObsPos_, auxRBPos), 6);
                if (distance_ < nearest_distance || nearest_distance == -1)
                {
                    nearest_obstacle = obs;
                    nearest_distance = distance_;
                }
            }
            if(nearest_obstacle != null)
            {
                Vector3 auxObsPos = new Vector3(nearest_obstacle.transform.position.x, 0, nearest_obstacle.transform.position.z);
                float distance = Mathf.Min(Vector3.Distance(auxObsPos, auxRBPos), 6);

                float influence = 6 - distance;
                Vector3 projectionVec = Vector3.Dot(rb.transform.forward, auxObsPos - auxRBPos) * rb.transform.forward;
                Vector3 avoidDirection = (auxObsPos - auxRBPos - projectionVec).normalized * -1;
                //Vector3 avoidDirection = (projectionVec- auxRBPos- auxObsPos).normalized;
                Vector3 avoidForce = (avoidDirection * influence);
                obstacle_avoid_force += avoidForce - currentVelocity;
                avoidLines.Add(avoidDirection * influence + auxObsPos);
                avoidPoses.Add(auxObsPos);
            }
            
            


        }
        //print("vel: " + velx + " " + vely);
        Vector3 totalForce = steering_force_seek*influence_seek + defalt_force+ obstacle_avoid_force*influence_avoid+ steering_force_evade* influence_evade;
        totalForce = Truncate(totalForce, 100);
        Vector3 acceleration = totalForce / rb.mass;
        currentVelocity += acceleration * Time.deltaTime;
        currentVelocity = Truncate(currentVelocity, MAX_SPEED);
        rb.position += currentVelocity * Time.deltaTime;

        if (currentVelocity != Vector3.zero)
        {
            transform.rotation = Quaternion.LookRotation(currentVelocity, Vector3.up);
        }
        anim.SetFloat("velx", -currentVelocity.x);
        anim.SetFloat("vely", currentVelocity.z);
        */
    }

    Vector3 Truncate(Vector3 v, float max)
    {
        float size = Mathf.Min(v.magnitude, max);
        return v.normalized * size;
    }
    void assignTarget()
    {
        //crowdController cc = crowd.GetComponent<crowdController>();
        //target = cc.GetRandomTarget();
    }
    void assignNewGoal()
    {
        graph.ResetGraph(transform.position, transform.rotation);
        goalSteps.Clear();
        //gridController gcc = walls.GetComponent<gridController>();
        //Grid grid = walls.GetComponent<gridController>().grid;
        //GridCell start = walls.GetComponent<gridController>().getNodeGivenPosition(new Vector2(rb.position.x, rb.position.z));
        Vector2 endPos;

        //endPos= walls.GetComponent<gridController>().GetRandomAvailableCell();
        //GridCell end = walls.GetComponent<gridController>().getNodeGivenPosition(endPos);
        //GridHeuristic hr = new GridHeuristic(end);
        int found = -1;
        float new_x = Random.Range(0, MAX_DIST_X - 1);
        float new_z = Random.Range(0, MAX_DIST_Y - 1);
        MotionNode endNode = new MotionNode(-1,0, new Vector3(new_x, transform.position.y, new_z), new Quaternion(0, 0, 0, 1));
        MotionHeuristic hr = new MotionHeuristic(endNode);
        currEndNode = endNode;
        currListNodes = pathFinderA_Star.findpath(graph, graph.nodes[0], endNode, hr, ref found);
        for(int i=0; i < currListNodes.Count; ++i)
        {
            goalSteps.Add((animStates)currListNodes[i].id_enum);
        }
        //if (goalSteps.Count == 0)
        //    assignTarget();

        
    }


    private void OnDrawGizmos()
    {
        
        if(debug_enabled)
        {
            Gizmos.color = Color.red;
            foreach (MotionNode gc in currListNodes)
            {
                Gizmos.DrawSphere(new Vector3(gc.position.x, 1, gc.position.z), 0.5f);
            }
            Gizmos.color = Color.blue;

 


            Gizmos.color = Color.green;
            Gizmos.DrawSphere(new Vector3(currEndNode.position.x, 1, currEndNode.position.z), 0.6f);
            Gizmos.DrawLine(rb.transform.forward + rb.transform.position, rb.transform.position);
        }
        

    }
}
